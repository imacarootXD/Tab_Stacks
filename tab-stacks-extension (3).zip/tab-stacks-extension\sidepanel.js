const STORAGE_KEY = "tabStacksSessions";
const PREFS_KEY = "tabStacksPrefs";
const GROUP_COLORS = new Set(["grey", "blue", "red", "yellow", "green", "pink", "purple", "cyan", "orange"]);

const elements = {
  tabSummary: document.getElementById("tab-summary"),
  sessionCount: document.getElementById("session-count"),
  sessionList: document.getElementById("session-list"),
  sessionSearch: document.getElementById("session-search"),
  clearSearchButton: document.getElementById("clear-search-button"),
  saveButton: document.getElementById("save-button"),
  saveCloseButton: document.getElementById("save-close-button"),
  suspendRestoreToggle: document.getElementById("suspend-restore-toggle"),
  refreshButton: document.getElementById("refresh-button"),
  exportButton: document.getElementById("export-button"),
  importButton: document.getElementById("import-button"),
  importFileInput: document.getElementById("import-file-input"),
  toast: document.getElementById("toast"),
  toastMessage: document.getElementById("toast-message"),
  toastAction: document.getElementById("toast-action")
};

let sessions = [];
let expandedSessionId = null;
let renamingSessionId = null;
let searchQuery = "";
let toastTimer = null;
let toastActionHandler = null;
let persistTimer = null;
let telemetryTimer = null;
let confirmCloseTimer = null;
let awaitingCloseConfirm = false;

function makeId() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
}

function showToast(message, options = {}) {
  const opts = typeof options === "boolean" ? { isError: options } : options;
  elements.toastMessage.textContent = message;
  elements.toast.classList.toggle("error", Boolean(opts.isError));

  if (opts.actionLabel && typeof opts.onAction === "function") {
    toastActionHandler = opts.onAction;
    elements.toastAction.textContent = opts.actionLabel;
    elements.toastAction.hidden = false;
  } else {
    toastActionHandler = null;
    elements.toastAction.hidden = true;
  }

  elements.toast.classList.add("visible");
  clearTimeout(toastTimer);
  const duration = opts.actionLabel ? 5500 : 3200;
  toastTimer = setTimeout(() => {
    elements.toast.classList.remove("visible");
    toastActionHandler = null;
  }, duration);
}

function formatDate(timestamp) {
  try {
    return new Intl.DateTimeFormat(undefined, {
      dateStyle: "medium",
      timeStyle: "short"
    }).format(new Date(timestamp));
  } catch {
    return new Date(timestamp).toLocaleString();
  }
}

function isRestorableUrl(rawUrl) {
  if (!rawUrl) return false;
  try {
    const url = new URL(rawUrl);
    return url.protocol === "http:" || url.protocol === "https:" || rawUrl === "about:blank";
  } catch {
    return false;
  }
}

function isSafeFaviconUrl(rawUrl) {
  if (!rawUrl) return false;
  try {
    const url = new URL(rawUrl);
    return url.protocol === "http:" || url.protocol === "https:" || rawUrl.startsWith("data:image/");
  } catch {
    return false;
  }
}

async function loadSessions() {
  const stored = await chrome.storage.local.get([STORAGE_KEY, PREFS_KEY]);
  sessions = Array.isArray(stored[STORAGE_KEY]) ? stored[STORAGE_KEY] : [];
  sessions.sort((a, b) => b.createdAt - a.createdAt);

  const prefs = stored[PREFS_KEY] || {};
  elements.suspendRestoreToggle.checked = Boolean(prefs.suspendBackground);
}

async function persistSessions() {
  clearTimeout(persistTimer);
  persistTimer = null;
  await chrome.storage.local.set({ [STORAGE_KEY]: sessions });
}

function schedulePersistSessions() {
  clearTimeout(persistTimer);
  persistTimer = setTimeout(() => {
    persistSessions().catch((error) => {
      console.error(error);
      showToast("Could not save the latest note edit.", true);
    });
  }, 350);
}

async function persistPrefs() {
  await chrome.storage.local.set({
    [PREFS_KEY]: { suspendBackground: elements.suspendRestoreToggle.checked }
  });
}

async function refreshTabSummary() {
  try {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const groupedIds = new Set(tabs.filter((tab) => tab.groupId !== -1).map((tab) => tab.groupId));
    elements.tabSummary.textContent = `${tabs.length} open tab${tabs.length === 1 ? "" : "s"} · ${groupedIds.size} tab group${groupedIds.size === 1 ? "" : "s"}`;
  } catch (error) {
    elements.tabSummary.textContent = "Could not read the current window";
    console.error(error);
  }
}

function scheduleTelemetryRefresh() {
  clearTimeout(telemetryTimer);
  telemetryTimer = setTimeout(refreshTabSummary, 120);
}

function registerLiveTelemetry() {
  if (chrome.tabs) {
    chrome.tabs.onCreated.addListener(scheduleTelemetryRefresh);
    chrome.tabs.onRemoved.addListener(scheduleTelemetryRefresh);
    chrome.tabs.onAttached.addListener(scheduleTelemetryRefresh);
    chrome.tabs.onDetached.addListener(scheduleTelemetryRefresh);
    chrome.tabs.onUpdated.addListener((_tabId, changeInfo) => {
      if (
        changeInfo.groupId !== undefined ||
        changeInfo.pinned !== undefined ||
        changeInfo.url !== undefined ||
        changeInfo.status === "complete"
      ) {
        scheduleTelemetryRefresh();
      }
    });
  }
  if (chrome.tabGroups) {
    chrome.tabGroups.onCreated.addListener(scheduleTelemetryRefresh);
    chrome.tabGroups.onUpdated.addListener(scheduleTelemetryRefresh);
    chrome.tabGroups.onRemoved.addListener(scheduleTelemetryRefresh);
  }
}

async function captureCurrentWindow() {
  const tabs = await chrome.tabs.query({ currentWindow: true });
  const realGroupIds = [...new Set(tabs.filter((tab) => tab.groupId !== -1).map((tab) => tab.groupId))];
  const groupMetadata = new Map();

  for (const groupId of realGroupIds) {
    try {
      const group = await chrome.tabGroups.get(groupId);
      groupMetadata.set(groupId, {
        title: group.title || "Saved group",
        color: GROUP_COLORS.has(group.color) ? group.color : "grey",
        collapsed: Boolean(group.collapsed)
      });
    } catch (error) {
      console.warn(`Could not read tab group ${groupId}`, error);
      groupMetadata.set(groupId, { title: "Saved group", color: "grey", collapsed: false });
    }
  }

  const buckets = new Map();
  for (const tab of tabs) {
    const groupKey = tab.groupId === -1 ? "ungrouped" : `group-${tab.groupId}`;
    if (!buckets.has(groupKey)) {
      const metadata = tab.groupId === -1
        ? { title: "Ungrouped tabs", color: "grey", collapsed: false, isUngrouped: true }
        : { ...groupMetadata.get(tab.groupId), isUngrouped: false };
      buckets.set(groupKey, { id: groupKey, ...metadata, tabs: [] });
    }

    const url = tab.url || tab.pendingUrl || "";
    buckets.get(groupKey).tabs.push({
      url,
      title: tab.title || url || "Untitled tab",
      favIconUrl: tab.favIconUrl || "",
      pinned: Boolean(tab.pinned),
      active: Boolean(tab.active),
      restorable: isRestorableUrl(url)
    });
  }

  const groups = [...buckets.values()];
  const allTabs = groups.flatMap((group) => group.tabs);
  const restorableTabs = allTabs.filter((tab) => tab.restorable).length;
  return {
    id: makeId(),
    name: `Session — ${new Date().toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" })}`,
    createdAt: Date.now(),
    notes: "",
    groups,
    totalTabs: allTabs.length,
    restorableTabs,
    protectedTabs: allTabs.length - restorableTabs
  };
}

function createElement(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function addButton(parent, text, action, className = "small-action", extra = {}) {
  const button = createElement("button", className, text);
  button.type = "button";
  button.dataset.action = action;
  Object.entries(extra).forEach(([key, value]) => { button.dataset[key] = value; });
  parent.append(button);
  return button;
}

function matchesSearch(session, query) {
  if (!query) return true;
  const q = query.toLowerCase();
  if ((session.name || "").toLowerCase().includes(q)) return true;
  if ((session.notes || "").toLowerCase().includes(q)) return true;

  for (const group of session.groups || []) {
    if ((group.title || "").toLowerCase().includes(q)) return true;
    for (const tab of group.tabs || []) {
      if ((tab.title || "").toLowerCase().includes(q)) return true;
      if ((tab.url || "").toLowerCase().includes(q)) return true;
    }
  }
  return false;
}

function renderEmptyState(isFiltered = false) {
  const empty = createElement("div", "empty-state");
  empty.append(createElement("span", "empty-icon", isFiltered ? "⌕" : "▤"));
  empty.append(createElement("strong", "", isFiltered ? "No matching sessions" : "No saved sessions yet"));
  empty.append(createElement(
    "p",
    "",
    isFiltered
      ? "Try a different keyword or clear the search filter."
      : "Save this window to keep its tabs and groups ready for later."
  ));
  elements.sessionList.append(empty);
}

function renderFavicon(tab) {
  if (isSafeFaviconUrl(tab.favIconUrl)) {
    const img = createElement("img", "tab-favicon");
    img.src = tab.favIconUrl;
    img.alt = "";
    img.loading = "lazy";
    img.addEventListener("error", () => {
      img.replaceWith(createElement("span", "tab-favicon-fallback", "•"));
    }, { once: true });
    return img;
  }
  return createElement("span", "tab-favicon-fallback", "•");
}

function renderGroup(session, group) {
  const block = createElement("div", "group-block");
  const titleRow = createElement("div", "group-title-row");
  const swatch = createElement("span", "group-swatch");
  swatch.style.setProperty("--group-color", group.isUngrouped ? "#8993a2" : chromeGroupColor(group.color));
  titleRow.append(swatch);
  titleRow.append(createElement("span", "group-title", group.title || "Saved group"));
  titleRow.append(createElement("span", "group-count", `${group.tabs.length} tab${group.tabs.length === 1 ? "" : "s"}`));

  const hasRestorable = (group.tabs || []).some((tab) => isRestorableUrl(tab.url));
  if (hasRestorable) {
    addButton(titleRow, "Restore group", "restore-group", "small-action group-restore-btn", {
      id: session.id,
      groupId: group.id
    });
  }
  block.append(titleRow);

  for (const tab of group.tabs || []) {
    const restorable = isRestorableUrl(tab.url);
    const row = createElement("div", `tab-row${restorable ? " is-clickable" : ""}`);
    if (restorable) {
      row.dataset.action = "open-tab";
      row.dataset.url = tab.url;
      row.title = `Open ${tab.title || tab.url}`;
      row.tabIndex = 0;
      row.setAttribute("role", "button");
    }

    row.append(renderFavicon(tab));

    const copy = createElement("div", "tab-copy");
    copy.append(createElement("span", "tab-title", `${tab.pinned ? "📌 " : ""}${tab.title || "Untitled tab"}`));
    copy.append(createElement("span", "tab-url", tab.url || "URL unavailable"));
    row.append(copy);

    if (!restorable) {
      row.append(createElement("span", "protected-badge", "Protected"));
    }
    block.append(row);
  }
  return block;
}

function chromeGroupColor(color) {
  const colors = {
    grey: "#8792a2", blue: "#4d7de8", red: "#e05b5b", yellow: "#d5a52c",
    green: "#37a477", pink: "#d66ba7", purple: "#9366d6", cyan: "#31a9bd", orange: "#dc8742"
  };
  return colors[color] || colors.grey;
}

function renderSession(session) {
  const card = createElement("article", `session-card${expandedSessionId === session.id ? " is-open" : ""}`);
  const top = createElement("div", "session-card-top");

  if (renamingSessionId === session.id) {
    const input = createElement("input", "rename-input");
    input.type = "text";
    input.value = session.name;
    input.dataset.renameSession = session.id;
    input.setAttribute("aria-label", "Session name");
    top.append(input);
    addButton(top, "Save", "commit-rename", "small-action", { id: session.id });
    addButton(top, "Cancel", "cancel-rename", "small-action", { id: session.id });
    card.append(top);
    requestAnimationFrame(() => {
      input.focus();
      input.select();
    });
  } else {
    const expand = createElement("button", "expand-button");
    expand.type = "button";
    expand.dataset.action = "toggle";
    expand.dataset.id = session.id;
    const name = createElement("span", "session-name", session.name);
    const metaText = session.updatedAt
      ? `${formatDate(session.createdAt)} · updated`
      : formatDate(session.createdAt);
    const meta = createElement("span", "session-meta", metaText);
    expand.append(createElement("span", "chevron", "›"), name, meta);
    top.append(expand);
    top.append(createElement("span", "count-pill", `${session.totalTabs} tabs`));
    addButton(top, "Restore", "restore", "small-action", { id: session.id });
    addButton(top, "Rename", "rename", "small-action", { id: session.id });
    addButton(top, "Delete", "delete", "small-action danger", { id: session.id });
    card.append(top);
  }

  if (expandedSessionId === session.id) {
    const details = createElement("div", "session-details");

    const headerRow = createElement("div", "detail-header-row");
    headerRow.append(createElement("label", "detail-label", "Session detail pad"));
    addButton(headerRow, "Update with current window", "update-session", "small-action", { id: session.id });
    details.append(headerRow);

    const notes = createElement("textarea", "notes-box");
    notes.placeholder = "Add context, reminders, research notes or anything you want to carry into the next session…";
    notes.value = session.notes || "";
    notes.dataset.sessionNotes = session.id;
    notes.setAttribute("aria-label", `Notes for ${session.name}`);
    details.append(notes);

    const actions = createElement("div", "detail-actions");
    addButton(actions, "Copy text", "copy-details", "button button-secondary", { id: session.id });
    addButton(actions, "Copy Markdown", "copy-markdown", "button button-secondary", { id: session.id });
    addButton(actions, "Insert into focused field", "insert-details", "button button-primary span-full", { id: session.id });
    details.append(actions);

    const groups = createElement("div", "group-list");
    for (const group of session.groups || []) groups.append(renderGroup(session, group));
    details.append(groups);

    if (session.protectedTabs > 0) {
      details.append(createElement("p", "protected-note", `${session.protectedTabs} protected browser tab${session.protectedTabs === 1 ? " was" : "s were"} recorded but cannot be restored by the extension.`));
    }
    card.append(details);
  }

  return card;
}

function render() {
  elements.sessionList.replaceChildren();
  const filtered = sessions.filter((session) => matchesSearch(session, searchQuery));

  if (searchQuery) {
    elements.sessionCount.textContent = `${filtered.length} of ${sessions.length} session${sessions.length === 1 ? "" : "s"}`;
  } else {
    elements.sessionCount.textContent = `${sessions.length} saved session${sessions.length === 1 ? "" : "s"}`;
  }

  if (filtered.length === 0) {
    renderEmptyState(Boolean(searchQuery));
    return;
  }
  for (const session of filtered) elements.sessionList.append(renderSession(session));
}

function resetCloseConfirm() {
  awaitingCloseConfirm = false;
  clearTimeout(confirmCloseTimer);
  confirmCloseTimer = null;
  elements.saveCloseButton.classList.remove("is-confirming");
  elements.saveCloseButton.textContent = "Save & close tabs";
}

async function saveCurrentSession(closeAfterSave = false) {
  resetCloseConfirm();
  setBusy(true);
  try {
    const session = await captureCurrentWindow();
    if (session.totalTabs === 0) {
      showToast("There are no tabs in this window to save.", true);
      return;
    }

    sessions.unshift(session);
    await persistSessions();
    expandedSessionId = session.id;
    render();

    if (!closeAfterSave) {
      showToast(`Saved ${session.totalTabs} tab${session.totalTabs === 1 ? "" : "s"} in ${session.groups.length} group${session.groups.length === 1 ? "" : "s"}.`);
      return;
    }

    const tabs = await chrome.tabs.query({ currentWindow: true });
    const closableIds = tabs
      .filter((tab) => isRestorableUrl(tab.url || tab.pendingUrl || ""))
      .map((tab) => tab.id);

    if (closableIds.length === 0) {
      showToast("Session saved. No restorable web tabs were found to close.");
      return;
    }

    if (closableIds.length === tabs.length) {
      await chrome.tabs.create({ url: "about:blank", active: true });
    }

    await chrome.tabs.remove(closableIds);
    await refreshTabSummary();
    const remaining = tabs.length - closableIds.length;
    const protectedMessage = remaining > 0
      ? ` ${remaining} protected tab${remaining === 1 ? " remains" : "s remain"}.`
      : " A blank tab was left open.";
    showToast(`Saved and closed ${closableIds.length} tab${closableIds.length === 1 ? "" : "s"}.${protectedMessage}`);
  } catch (error) {
    console.error(error);
    showToast(`Could not save the session: ${error.message || "Unknown error"}`, true);
  } finally {
    setBusy(false);
    await refreshTabSummary();
  }
}

function setBusy(busy) {
  elements.saveButton.disabled = busy;
  elements.saveCloseButton.disabled = busy;
  elements.refreshButton.disabled = busy;
  elements.saveButton.textContent = busy ? "Saving…" : "Save session";
  if (!awaitingCloseConfirm) {
    elements.saveCloseButton.textContent = busy ? "Working…" : "Save & close tabs";
  }
}

function buildSessionDetails(session) {
  const lines = [
    `SESSION: ${session.name}`,
    `SAVED: ${formatDate(session.createdAt)}`,
    `TABS: ${session.totalTabs}`,
    ""
  ];
  if (session.notes?.trim()) lines.push("NOTES:", session.notes.trim(), "");
  lines.push("TABS BY GROUP:");
  for (const group of session.groups || []) {
    lines.push("", `${group.title || "Saved group"}${group.isUngrouped ? " (ungrouped)" : ""}`);
    for (const tab of group.tabs || []) {
      lines.push(`- ${tab.title || "Untitled tab"}`, `  ${tab.url || "URL unavailable"}`);
    }
  }
  if (session.protectedTabs > 0) {
    lines.push("", `Protected tabs not restorable by the extension: ${session.protectedTabs}`);
  }
  return lines.join("\n");
}

function buildSessionMarkdown(session) {
  const lines = [
    `## ${session.name}`,
    `*Saved ${formatDate(session.createdAt)} · ${session.totalTabs} tab${session.totalTabs === 1 ? "" : "s"}*`,
    ""
  ];
  if (session.notes?.trim()) {
    lines.push("### Notes", session.notes.trim(), "");
  }
  for (const group of session.groups || []) {
    lines.push(`### ${group.title || "Saved group"}`);
    for (const tab of group.tabs || []) {
      const title = (tab.title || "Untitled tab").replace(/[\[\]]/g, "\\$&");
      if (isRestorableUrl(tab.url)) {
        lines.push(`- [${title}](${tab.url})`);
      } else {
        lines.push(`- ${title} (\`${tab.url || "protected"}\`)`);
      }
    }
    lines.push("");
  }
  return lines.join("\n").trim();
}

async function copyText(text, successMessage) {
  try {
    await navigator.clipboard.writeText(text);
    showToast(successMessage);
  } catch (error) {
    console.error(error);
    showToast("Clipboard access was blocked. Select and copy the detail pad text manually.", true);
  }
}

async function insertSessionDetails(session) {
  const text = buildSessionDetails(session);
  try {
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!activeTab?.id) throw new Error("No active webpage was found.");

    const results = await chrome.scripting.executeScript({
      target: { tabId: activeTab.id },
      func: (content) => {
        const element = document.activeElement;
        if (!element) return { ok: false, reason: "focus" };

        const isTextArea = element instanceof HTMLTextAreaElement;
        const isEditableInput = element instanceof HTMLInputElement &&
          ["text", "search", "url", "email", "tel"].includes((element.type || "text").toLowerCase());
        const isContentEditable = element.isContentEditable || element.closest?.("[contenteditable='true']");

        if (isTextArea || isEditableInput) {
          const start = typeof element.selectionStart === "number" ? element.selectionStart : element.value.length;
          const end = typeof element.selectionEnd === "number" ? element.selectionEnd : element.value.length;
          const inserted = isEditableInput ? content.replace(/\s*\n\s*/g, " ") : content;
          element.setRangeText(inserted, start, end, "end");
          element.dispatchEvent(new Event("input", { bubbles: true }));
          element.dispatchEvent(new Event("change", { bubbles: true }));
          return { ok: true };
        }

        if (isContentEditable) {
          const target = element.isContentEditable ? element : element.closest("[contenteditable='true']");
          target.focus();
          const inserted = document.execCommand("insertText", false, content);
          if (inserted) return { ok: true };
          return { ok: false, reason: "contenteditable" };
        }
        return { ok: false, reason: "focus" };
      },
      args: [text]
    });

    const result = results?.[0]?.result;
    if (result?.ok) showToast("Session details inserted into the focused field. Nothing was submitted.");
    else showToast("Click a text box or editable area on the webpage first, then try again.", true);
  } catch (error) {
    console.error(error);
    showToast("Chrome blocked access to this page. Use Copy text instead.", true);
  }
}

async function restoreGroups(groupsToRestore, { activateSavedTab = true } = {}) {
  const allSavedTabs = groupsToRestore.flatMap((group) => group.tabs || []);
  const specs = [];

  for (const group of groupsToRestore) {
    for (const savedTab of group.tabs || []) {
      if (!isRestorableUrl(savedTab.url)) continue;
      specs.push({ savedTab, group });
    }
  }

  if (specs.length === 0) {
    showToast("No restorable tabs were found.", true);
    return;
  }

  setBusy(true);
  const suspendBackground = elements.suspendRestoreToggle.checked;
  const createdByGroup = new Map();
  const tabsToDiscard = [];
  let activeTabId = null;
  let restoredCount = 0;
  let failures = 0;

  try {
    const results = await Promise.allSettled(
      specs.map(({ savedTab }) =>
        chrome.tabs.create({
          url: savedTab.url,
          active: false,
          pinned: Boolean(savedTab.pinned)
        })
      )
    );

    results.forEach((result, index) => {
      const { savedTab, group } = specs[index];
      if (result.status !== "fulfilled") {
        failures += 1;
        console.warn(`Could not restore tab ${savedTab.url}`, result.reason);
        return;
      }

      const created = result.value;
      restoredCount += 1;

      const isTargetActive = activateSavedTab && savedTab.active && !savedTab.pinned;
      if (isTargetActive) {
        activeTabId = created.id;
      } else if (suspendBackground) {
        tabsToDiscard.push(created.id);
      }

      if (!group.isUngrouped && !savedTab.pinned) {
        if (!createdByGroup.has(group.id)) {
          createdByGroup.set(group.id, { savedGroup: group, tabIds: [] });
        }
        createdByGroup.get(group.id).tabIds.push(created.id);
      }
    });

    for (const { savedGroup, tabIds } of createdByGroup.values()) {
      if (tabIds.length === 0) continue;
      try {
        const groupId = await chrome.tabs.group({ tabIds });
        await chrome.tabGroups.update(groupId, {
          title: savedGroup.title || "Restored group",
          color: GROUP_COLORS.has(savedGroup.color) ? savedGroup.color : "grey",
          collapsed: Boolean(savedGroup.collapsed)
        });
      } catch (error) {
        console.warn("Could not recreate a tab group; its tabs remain open", error);
        failures += tabIds.length;
      }
    }

    if (activeTabId) {
      try {
        await chrome.tabs.update(activeTabId, { active: true });
      } catch {
        // Tab may have closed meanwhile.
      }
    }

    if (suspendBackground && tabsToDiscard.length > 0) {
      await Promise.allSettled(tabsToDiscard.map((id) => chrome.tabs.discard(id)));
    }

    await refreshTabSummary();
    const skipped = allSavedTabs.length - specs.length;
    const messages = [`Restored ${restoredCount} tab${restoredCount === 1 ? "" : "s"}`];
    if (suspendBackground && tabsToDiscard.length > 0) messages.push("background tabs suspended");
    if (skipped) messages.push(`${skipped} protected skipped`);
    if (failures) messages.push(`${failures} could not be restored`);
    showToast(`${messages.join(" · ")}.`, failures > 0);
  } catch (error) {
    console.error(error);
    showToast(`Restore failed: ${error.message || "Unknown error"}`, true);
  } finally {
    setBusy(false);
  }
}

async function commitRename(sessionId) {
  const input = elements.sessionList.querySelector(`input[data-rename-session="${sessionId}"]`);
  const session = sessions.find((item) => item.id === sessionId);
  if (!input || !session) {
    renamingSessionId = null;
    render();
    return;
  }

  const trimmed = input.value.trim();
  if (!trimmed) {
    showToast("A session name cannot be empty.", true);
    input.focus();
    return;
  }

  session.name = trimmed;
  renamingSessionId = null;
  await persistSessions();
  render();
  showToast("Session renamed.");
}

async function updateSessionFromWindow(session) {
  const fresh = await captureCurrentWindow();
  if (fresh.totalTabs === 0) {
    showToast("There are no tabs in this window to capture.", true);
    return;
  }

  const previousSnapshot = structuredClone(session);
  session.groups = fresh.groups;
  session.totalTabs = fresh.totalTabs;
  session.restorableTabs = fresh.restorableTabs;
  session.protectedTabs = fresh.protectedTabs;
  session.updatedAt = Date.now();

  await persistSessions();
  render();
  showToast(`Updated “${session.name}” (${session.totalTabs} tabs).`, {
    actionLabel: "Undo",
    onAction: async () => {
      const idx = sessions.findIndex((item) => item.id === previousSnapshot.id);
      if (idx !== -1) {
        sessions[idx] = previousSnapshot;
        await persistSessions();
        render();
        showToast("Reverted session update.");
      }
    }
  });
}

async function handleSessionAction(event) {
  const actionTarget = event.target.closest("[data-action]");
  if (!actionTarget) return;

  const action = actionTarget.dataset.action;

  if (action === "open-tab") {
    const url = actionTarget.dataset.url;
    if (isRestorableUrl(url)) {
      await chrome.tabs.create({ url, active: true });
    }
    return;
  }

  const session = sessions.find((item) => item.id === actionTarget.dataset.id);

  if (action === "toggle") {
    expandedSessionId = expandedSessionId === actionTarget.dataset.id ? null : actionTarget.dataset.id;
    render();
    return;
  }
  if (!session) return;

  if (action === "rename") {
    renamingSessionId = session.id;
    render();
  } else if (action === "commit-rename") {
    await commitRename(session.id);
  } else if (action === "cancel-rename") {
    renamingSessionId = null;
    render();
  } else if (action === "delete") {
    const removedIndex = sessions.findIndex((item) => item.id === session.id);
    const removedSession = structuredClone(session);
    sessions.splice(removedIndex, 1);
    if (expandedSessionId === session.id) expandedSessionId = null;
    if (renamingSessionId === session.id) renamingSessionId = null;
    await persistSessions();
    render();

    showToast(`Deleted “${removedSession.name}”.`, {
      actionLabel: "Undo",
      onAction: async () => {
        sessions.splice(Math.min(removedIndex, sessions.length), 0, removedSession);
        await persistSessions();
        render();
        showToast("Session restored.");
      }
    });
  } else if (action === "restore") {
    await restoreGroups(session.groups || [], { activateSavedTab: true });
  } else if (action === "restore-group") {
    const group = (session.groups || []).find((g) => g.id === actionTarget.dataset.groupId);
    if (group) {
      await restoreGroups([group], { activateSavedTab: false });
    }
  } else if (action === "update-session") {
    await updateSessionFromWindow(session);
  } else if (action === "copy-details") {
    await copyText(buildSessionDetails(session), "Session details copied to the clipboard.");
  } else if (action === "copy-markdown") {
    await copyText(buildSessionMarkdown(session), "Markdown outline copied to the clipboard.");
  } else if (action === "insert-details") {
    await insertSessionDetails(session);
  }
}

function exportSessionsJson() {
  const payload = {
    app: "Tab Stacks",
    version: 1,
    exportedAt: new Date().toISOString(),
    sessions
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `tab-stacks-backup-${new Date().toISOString().slice(0, 10)}.json`;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  showToast(`Exported ${sessions.length} session${sessions.length === 1 ? "" : "s"}.`);
}

async function importSessionsJson(file) {
  try {
    const raw = await file.text();
    const parsed = JSON.parse(raw);
    const incoming = Array.isArray(parsed) ? parsed : parsed?.sessions;
    if (!Array.isArray(incoming)) {
      throw new Error("Invalid backup format.");
    }

    const existingIds = new Set(sessions.map((s) => s.id));
    let importedCount = 0;

    for (const item of incoming) {
      if (!item || typeof item !== "object" || !Array.isArray(item.groups)) continue;
      const cleanId = typeof item.id === "string" && !existingIds.has(item.id) ? item.id : makeId();
      existingIds.add(cleanId);

      const cleanGroups = item.groups.map((g, idx) => ({
        id: typeof g.id === "string" ? g.id : `group-${idx}`,
        title: typeof g.title === "string" ? g.title : "Saved group",
        color: GROUP_COLORS.has(g.color) ? g.color : "grey",
        collapsed: Boolean(g.collapsed),
        isUngrouped: Boolean(g.isUngrouped),
        tabs: Array.isArray(g.tabs)
          ? g.tabs.map((t) => {
              const url = typeof t.url === "string" ? t.url : "";
              return {
                url,
                title: typeof t.title === "string" ? t.title : url || "Untitled tab",
                favIconUrl: typeof t.favIconUrl === "string" ? t.favIconUrl : "",
                pinned: Boolean(t.pinned),
                active: Boolean(t.active),
                restorable: isRestorableUrl(url)
              };
            })
          : []
      }));

      const allTabs = cleanGroups.flatMap((g) => g.tabs);
      const restorableTabs = allTabs.filter((t) => t.restorable).length;

      sessions.push({
        id: cleanId,
        name: typeof item.name === "string" && item.name.trim() ? item.name.trim() : "Imported session",
        createdAt: typeof item.createdAt === "number" ? item.createdAt : Date.now(),
        updatedAt: typeof item.updatedAt === "number" ? item.updatedAt : undefined,
        notes: typeof item.notes === "string" ? item.notes : "",
        groups: cleanGroups,
        totalTabs: allTabs.length,
        restorableTabs,
        protectedTabs: allTabs.length - restorableTabs
      });
      importedCount += 1;
    }

    sessions.sort((a, b) => b.createdAt - a.createdAt);
    await persistSessions();
    render();
    showToast(`Imported ${importedCount} session${importedCount === 1 ? "" : "s"}.`);
  } catch (error) {
    console.error(error);
    showToast(`Import failed: ${error.message || "Invalid JSON file"}`, true);
  }
}

elements.sessionList.addEventListener("click", handleSessionAction);

elements.sessionList.addEventListener("keydown", async (event) => {
  const renameInput = event.target.closest("input[data-rename-session]");
  if (renameInput) {
    if (event.key === "Enter") {
      event.preventDefault();
      await commitRename(renameInput.dataset.renameSession);
    } else if (event.key === "Escape") {
      event.preventDefault();
      renamingSessionId = null;
      render();
    }
    return;
  }

  const clickableTab = event.target.closest(".tab-row.is-clickable");
  if (clickableTab && (event.key === "Enter" || event.key === " ")) {
    event.preventDefault();
    const url = clickableTab.dataset.url;
    if (isRestorableUrl(url)) {
      await chrome.tabs.create({ url, active: true });
    }
  }
});

elements.sessionList.addEventListener("input", (event) => {
  const notes = event.target.closest("textarea[data-session-notes]");
  if (!notes) return;
  const session = sessions.find((item) => item.id === notes.dataset.sessionNotes);
  if (session) {
    session.notes = notes.value;
    schedulePersistSessions();
  }
});

elements.sessionList.addEventListener("focusout", (event) => {
  if (event.target.matches("textarea[data-session-notes]") && persistTimer) {
    persistSessions().catch(console.error);
  }
});

document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "hidden" && persistTimer) {
    persistSessions().catch(console.error);
  }
});

elements.sessionSearch.addEventListener("input", () => {
  searchQuery = elements.sessionSearch.value.trim();
  elements.clearSearchButton.hidden = searchQuery.length === 0;
  render();
});

elements.clearSearchButton.addEventListener("click", () => {
  searchQuery = "";
  elements.sessionSearch.value = "";
  elements.clearSearchButton.hidden = true;
  render();
  elements.sessionSearch.focus();
});

elements.suspendRestoreToggle.addEventListener("change", () => {
  persistPrefs().catch(console.error);
});

elements.saveButton.addEventListener("click", () => saveCurrentSession(false));

elements.saveCloseButton.addEventListener("click", async () => {
  if (!awaitingCloseConfirm) {
    awaitingCloseConfirm = true;
    elements.saveCloseButton.classList.add("is-confirming");
    elements.saveCloseButton.textContent = "Confirm save & close?";
    confirmCloseTimer = setTimeout(resetCloseConfirm, 3500);
    return;
  }
  await saveCurrentSession(true);
});

elements.refreshButton.addEventListener("click", refreshTabSummary);
elements.exportButton.addEventListener("click", exportSessionsJson);
elements.importButton.addEventListener("click", () => elements.importFileInput.click());
elements.importFileInput.addEventListener("change", async (event) => {
  const file = event.target.files?.[0];
  if (file) {
    await importSessionsJson(file);
    elements.importFileInput.value = "";
  }
});

elements.toastAction.addEventListener("click", async () => {
  const handler = toastActionHandler;
  clearTimeout(toastTimer);
  toastActionHandler = null;
  elements.toast.classList.remove("visible");
  if (handler) await handler();
});

(async function init() {
  try {
    registerLiveTelemetry();
    await loadSessions();
    render();
    await refreshTabSummary();
  } catch (error) {
    console.error(error);
    showToast("Tab Stacks could not load its local session storage.", true);
  }
})();
